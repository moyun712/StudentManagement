package dao;

public class MssageDao {

}
